# Images

Add your memorial photos here to replace the stock images.

Recommended specs:
- Format: JPG or WebP
- Hero image: 800x1000px minimum
- Gallery images: 500x500px minimum
- Optimise for web (compress to <200KB each)
